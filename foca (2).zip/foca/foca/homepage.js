let title = document.querySelector("#first-title")
let secondtitle = document.querySelector("#second-title")
title.textContent ="enthusiast"
secondtitle.textContent ="researcher"